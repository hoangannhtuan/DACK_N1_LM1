public class ACCOUT {
    String tendangnhap, password;

    public ACCOUT(String tendangnhap, String password) {
        this.tendangnhap = tendangnhap;
        this.password = password;
    }

}
