public class SANPHAM {
    String tensp;
    int dongia, soluong;

    public SANPHAM(String tensp, int dongia, int soluong) {
        this.tensp = tensp;
        this.dongia = dongia;
        this.soluong = soluong;
    }
}
